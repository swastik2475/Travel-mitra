#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char Comp_Name[50];
    int Capacity;
    float MRP;
} Fridge;

int main() {
    FILE *fp;
    Fridge fridges[9];
    int i, j, count = 0;
    char str[50];

    // Open the file for reading
    fp = fopen("Detail.txt", "r");

    // Check if the file is opened successfully
    if (fp == NULL) {
        printf("Error opening the file.\n");
        exit(1);
    }

    // Read the data from the file and store it in the array
    while (fscanf(fp, "%s %d %f", fridges[count].Comp_Name, &fridges[count].Capacity, &fridges[count].MRP)!= EOF) {
        count++;
    }

    // Close the file
    fclose(fp);

    // Sort the array based on the capacity
    for (i = 0; i < count - 1; i++) {
        for (j = i + 1; j < count; j++) {
            if (fridges[i].Capacity > fridges[j].Capacity) {
                Fridge temp = fridges[i];
                fridges[i] = fridges[j];
                fridges[j] = temp;
            }
        }
    }

    // Find and display each size fridge detail which are cheapest
    for (i = 0; i < count; i++) {
        if (i == 0 || fridges[i].Capacity!= fridges[i - 1].Capacity) {
            printf("Cheapest %d Ltr Fridge:\n", fridges[i].Capacity);
            printf("Company Name: %s\n", fridges[i].Comp_Name);
            printf("MRP: %.2f\n", fridges[i].MRP);
            printf("\n");
        }
    }

    return 0;
}