//Write a program in C to convert a text file contents in uppercase letters.



#include <stdio.h>
#include <ctype.h>

int main() {
    FILE *inputFile, *outputFile;
    char ch;

    // Open the input file in read mode
    inputFile = fopen("input.txt", "r");

    if (inputFile == NULL) {
        printf("Error opening the file.\n");
        return 1;
    }

    // Open the output file in write mode
    outputFile = fopen("output.txt", "w");

    if (outputFile == NULL) {
        printf("Error creating the output file.\n");
        fclose(inputFile);
        return 1;
    }

    // Read the input file character by character
    while ((ch = fgetc(inputFile)) != EOF) {
        // Convert to uppercase if it's a lowercase letter
        if (islower(ch)) {
            ch = toupper(ch);
        }

        // Write the character to the output file
        fputc(ch, outputFile);
    }

    // Close the files
    fclose(inputFile);
    fclose(outputFile);

    printf("File contents have been converted to uppercase successfully.\n");

    return 0;
}
