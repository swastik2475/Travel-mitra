Write a program in C to calculate the power of any number using recursion.


#include <stdio.h>

double power(double base, int exponent);

int main() {
    double base, result;
    int exponent;

    printf("Enter base number: ");
    scanf("%lf", &base);

    printf("Enter exponent: ");
    scanf("%d", &exponent);

    result = power(base, exponent);

    printf("%.2lf ^ %d = %.2lf\n", base, exponent, result);

    return 0;
}

double power(double base, int exponent) {
    // Base case
    if (exponent == 0) {
        return 1;
    }

    // Recursive case for positive exponent
    if (exponent > 0) {
        return base * power(base, exponent - 1);
    }
    // Recursive case for negative exponent
    else {
        return (1 / base) * power(base, exponent + 1);
    }
}
