#include <stdio.h>

int bitwiseSubtraction(int a, int b) {
    while (b != 0) {
        int borrow = (~a) & b;
        a ^= b;
        b = borrow << 1;
    }
    return a;
}

int main() {
    int num1, num2, result;

    printf("Enter the first integer: ");
    scanf("%d", &num1);
    printf("Enter the second integer: ");
    scanf("%d", &num2);

    result = bitwiseSubtraction(num1, num2);

    printf("Subtraction using bitwise operators: %d\n", result);

    return 0;
}
