//Write a program in C which is a Menu-Driven Program to compute the area of the six various geometrical shape. [Enter 1. Circle 2. Sphere 3. Cylinder 4. Ractangle etc].



#include <stdio.h>
#include <math.h>

#define PI 3.14159265

int main() {
    int choice;
    float radius, height, base, length, width, side, area;

    printf("Menu:\n");
    printf("1. Circle\n");
    printf("2. Sphere\n");
    printf("3. Cylinder\n");
    printf("4. Rectangle\n");
    printf("5. Triangle\n");
    printf("6. Square\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    switch (choice) {
        case 1:
            printf("Enter the radius of the circle: ");
            scanf("%f", &radius);
            area = PI * pow(radius, 2);
            printf("Area of the circle: %.2f\n", area);
            break;

        case 2:
            printf("Enter the radius of the sphere: ");
            scanf("%f", &radius);
            area = 4 * PI * pow(radius, 2);
            printf("Surface area of the sphere: %.2f\n", area);
            break;

        case 3:
            printf("Enter the radius of the cylinder: ");
            scanf("%f", &radius);
            printf("Enter the height of the cylinder: ");
            scanf("%f", &height);
            area = 2 * PI * radius * (radius + height);
            printf("Surface area of the cylinder: %.2f\n", area);
            break;

        case 4:
            printf("Enter the length of the rectangle: ");
            scanf("%f", &length);
            printf("Enter the width of the rectangle: ");
            scanf("%f", &width);
            area = length * width;
            printf("Area of the rectangle: %.2f\n", area);
            break;

        case 5:
            printf("Enter the base of the triangle: ");
            scanf("%f", &base);
            printf("Enter the height of the triangle: ");
            scanf("%f", &height);
            area = 0.5 * base * height;
            printf("Area of the triangle: %.2f\n", area);
            break;

        case 6:
            printf("Enter the side length of the square: ");
            scanf("%f", &side);
            area = pow(side, 2);
            printf("Area of the square: %.2f\n", area);
            break;

        default:
            printf("Invalid choice.\n");
    }

    return 0;
}
