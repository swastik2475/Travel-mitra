#include <stdio.h>

// Define structure for plots
struct Plots {
    int plot_id;
    float length;
    float width;
    float area;
    float price;
};

// Function to find highest cost and smallest size plot information
void find_highest_cost_and_smallest_size() {
    struct Plots smallest = {0, 0, 0, 0, 0};
    struct Plots highest = {0, 0, 0, 0, 0};
    FILE *file = fopen("Plotdetail.txt", "r");
    if (!file) {
        printf("Error opening file!\n");
        return;
    }
    struct Plots plot;
    while (fscanf(file, "%d%f%f%f%f", &plot.plot_id, &plot.length, &plot.width, &plot.area, &plot.price) == 5) {
        if (smallest.area == 0 || plot.area < smallest.area)
            smallest = plot;
        if (plot.price > highest.price)
            highest = plot;
    }
    fclose(file);
    printf("Smallest Size Plot Information:\nPlot ID: %d\nArea: %.2f\n", smallest.plot_id, smallest.area);
    printf("\nHighest Cost Plot Information:\nPlot ID: %d\nPrice: %.2f\n", highest.plot_id, highest.price);
}

int main() {
    find_highest_cost_and_smallest_size();
    return 0;
}
