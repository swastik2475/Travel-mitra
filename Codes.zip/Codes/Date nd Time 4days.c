#include <stdio.h>
#include <time.h>

int main() {
    // Get the current time
    time_t now;
    time(&now);

    // Subtract 4 days (in seconds) from the current time
    time_t four_days_ago = now - (4 * 24 * 60 * 60);

    // Convert the time to struct tm
    struct tm *four_days_ago_tm = localtime(&four_days_ago);

    // Print the date and time before 4 days
    printf("Date and time before 4 days: %s", asctime(four_days_ago_tm));

    return 0;
}
