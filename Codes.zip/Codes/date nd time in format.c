#include <stdio.h>
#include <time.h>

int main() {
    time_t now = time(NULL);
    struct tm *now_tm = localtime(&now);

    // Print the date and time in the desired format
    printf("%s %s %d %02d:%02d:%02d %d\n",
           weekday[now_tm->tm_wday],
           month[now_tm->tm_mon],
           now_tm->tm_mday,
           now_tm->tm_hour,
           now_tm->tm_min,
           now_tm->tm_sec,
           1900 + now_tm->tm_year);

    return 0;
}