#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fptr;
    char fname[20] = "Sample.txt";

    printf("\n\n Create a file (Sample.txt) and input text :\n");
    printf("----------------------------------------------\n");
    fptr = fopen(fname, "w");
    if (fptr == NULL)
    {
        printf(" Error in opening file!");
        exit(1);
    }
    fprintf(fptr, "Hello, this is a sample text file created using C programming.\n");
    fclose(fptr);
    printf("\n The file %s created successfully...!!\n\n", fname);
    return 0;
}