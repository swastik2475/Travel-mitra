#include <stdio.h>

#define MAX_SIZE 100

// Function to print unique elements of an array
void printUniqueElements(int arr[], int size) {
    int isUnique[MAX_SIZE] = {0}; // Array to track unique elements
    int i, j;

    printf("Unique elements in the array: ");

    // Iterate through the array
    for (i = 0; i < size; i++) {
        // Check if arr[i] is already encountered
        int isAlreadyEncountered = 0;
        for (j = 0; j < i; j++) {
            if (arr[i] == arr[j]) {
                isAlreadyEncountered = 1;
                break;
            }
        }

        // If arr[i] is not encountered before, print it as unique
        if (!isAlreadyEncountered) {
            printf("%d ", arr[i]);
            isUnique[arr[i]] = 1; // Mark arr[i] as encountered
        }
    }

    printf("\n");

    // Optionally, you can print all unique elements in the array
    printf("All unique elements in the array: ");
    for (i = 0; i < size; i++) {
        if (isUnique[arr[i]]) {
            printf("%d ", arr[i]);
            isUnique[arr[i]] = 0; // Mark arr[i] as printed
        }
    }
    printf("\n");
}

int main() {
    int arr[] = {3, 1, 5, 3, 7, 5, 8, 1, 3, 9};
    int size = sizeof(arr) / sizeof(arr[0]);

    // Print unique elements of the array
    printUniqueElements(arr, size);

    return 0;
}
