#include <stdio.h>

void findRepeatingElements(int arr[], int size) {
    printf("The repeating elements in the array are: ");
    for (int i = 0; i < size; i++) {
        for (int j = i + 1; j < size; j++) {
            if (arr[i] == arr[j]) {
                printf("%d%d ", arr[i], arr[j]);
            }
        }
    }
    printf("\n");
}

int main() {
    int arr[] = {2, 7, 4, 7, 8, 3, 4}; // Given array
    int size = sizeof(arr) / sizeof(arr[0]);
    findRepeatingElements(arr, size);
    return 0;
}
