#include <stdio.h>
#include <math.h>

// Function to calculate factorial
double factorial(int n) {
    if (n == 0 || n == 1) {
        return 1.0;
    }
    double fact = 1.0;
    for (int i = 2; i <= n; i++) {
        fact *= i;
    }
    return fact;
}

int main() {
    double x = 2.0; // Value of x
    double precision = 0.0001; // Desired precision error
    double sum = 1.0; // Initialize sum with the first term (k = 0)

    // Loop to calculate the series sum until desired precision is reached
    int n = 1;
    while (1) {
        double term = pow(x, n) / factorial(n); // Calculate term for current n
        sum += term; // Add term to the sum

        // Check precision error
        if (fabs(term) < precision) {
            break; // Stop if term is smaller than precision error
        }

        n++; // Increment n for the next term
    }

    // Print the sum and the value of n that satisfies the precision error
    printf("Sum of the series: %.6f\n", sum);
    printf("Value of n for precision error <= %.6f: %d\n", precision, n);

    return 0;
}
