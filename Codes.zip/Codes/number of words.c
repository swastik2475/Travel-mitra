#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

// Function to count words in a file
int countWords(FILE *file) {
    int wordCount = 0;
    int inWord = 0; // Flag to track if we are inside a word

    // Read each character from the file
    int ch;
    while ((ch = fgetc(file)) != EOF) {
        // Check if the character is alphabetic or an apostrophe (') to identify word boundaries
        if (isalpha(ch) || ch == '\'') {
            if (!inWord) {
                // We encountered the start of a new word
                wordCount++;
                inWord = 1; // Set flag to indicate we are inside a word
            }
        } else {
            // We encountered a non-word character
            inWord = 0; // Reset flag
        }
    }

    return wordCount;
}

int main() {
    char filename[100];
    FILE *file;

    // Prompt user to enter the filename
    printf("Enter the filename: ");
    scanf("%s", filename);

    // Open the file in read mode
    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file. Please check if the file exists.\n");
        return 1;
    }

    // Count the number of words in the file
    int words = countWords(file);

    // Close the file
    fclose(file);

    // Display the word count
    printf("Number of words in the file: %d\n", words);

    return 0;
}
