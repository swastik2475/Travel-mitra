#include <stdio.h>

// Function to calculate factorial
unsigned long long factorial(int n) {
    if (n == 0 || n == 1) {
        return 1;
    } else {
        unsigned long long fact = 1;
        for (int i = 2; i <= n; i++) {
            fact *= i;
        }
        return fact;
    }
}

// Function to calculate binomial coefficient C(n, k)
unsigned long long binomialCoefficient(int n, int k) {
    if (k > n) {
        return 0;
    }
    return factorial(n) / (factorial(k) * factorial(n - k));
}

int main() {
    int numRows;

    // Prompt the user to enter the number of rows for Pascal's triangle
    printf("Enter the number of rows for Pascal's triangle: ");
    scanf("%d", &numRows);

    // Print Pascal's triangle
    for (int i = 0; i < numRows; i++) {
        // Print spaces for alignment
        for (int space = 0; space < numRows - i - 1; space++) {
            printf("   "); // Adjust spacing as needed
        }

        // Calculate and print values for each row
        for (int j = 0; j <= i; j++) {
            unsigned long long coef = binomialCoefficient(i, j);
            printf("%6llu   ", coef); // Adjust spacing as needed
        }

        printf("\n");
    }

    return 0;
}
