#include <stdio.h>

int main() {
    float temperature;

    // Prompt the user to enter the temperature in centigrade
    printf("Enter the temperature in centigrade: ");
    scanf("%f", &temperature);

    // Determine the temperature state and display a fuzzy message
    if (temperature >= 40.0) {
        printf("It's Very Hot\n");
    } else if (temperature >= 30.0) {
        printf("It's Hot\n");
    } else if (temperature >= 20.0) {
        printf("It's Warm\n");
    } else if (temperature >= 10.0) {
        printf("It's Cool\n");
    } else {
        printf("It's Cold\n");
    }

    return 0;
}
