#include <stdio.h>

int findMissingNumber(int arr[], int size) {
    int expected_sum = 45; // Sum of numbers from 1 to 9
    int actual_sum = 0;
    for (int i = 0; i < size; i++) {
        actual_sum += arr[i];
    }
    return expected_sum - actual_sum;
}

int main() {
    int arr[] = {1, 3, 4, 2, 5, 6, 9, 8}; // Given array
    int size = sizeof(arr) / sizeof(arr[0]);
    printf("The missing number from the given array is: %d\n", findMissingNumber(arr, size));
    return 0;
}
