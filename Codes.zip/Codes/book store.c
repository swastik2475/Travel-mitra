#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TITLE_LENGTH 100

// Define structure for Book
typedef struct {
    char title[MAX_TITLE_LENGTH];
    float price;
} Book;

// Function to write books to a file
void writeBooksToFile(Book books[], int numBooks, const char *filename) {
    FILE *file = fopen(filename, "wb"); // Open file for writing in binary mode
    if (file == NULL) {
        printf("Error: Unable to open file for writing.\n");
        return;
    }

    fwrite(books, sizeof(Book), numBooks, file); // Write array of books to file
    fclose(file); // Close file
}

// Function to read books from a file and find the most costly book
void findMostCostlyBook(const char *filename) {
    FILE *file = fopen(filename, "rb"); // Open file for reading in binary mode
    if (file == NULL) {
        printf("Error: Unable to open file for reading.\n");
        return;
    }

    Book books[6]; // Assuming there are 6 books stored in the file
    fread(books, sizeof(Book), 6, file); // Read array of books from file
    fclose(file); // Close file

    // Find the most costly book
    Book mostCostlyBook = books[0];
    for (int i = 1; i < 6; i++) {
        if (books[i].price > mostCostlyBook.price) {
            mostCostlyBook = books[i];
        }
    }

    // Display the details of the most costly book
    printf("Most costly book details:\n");
    printf("Title: %s\n", mostCostlyBook.title);
    printf("Price: %.2f\n", mostCostlyBook.price);
}

int main() {
    // Create an array of Book structures representing six books
    Book books[6] = {
        {"Book1", 25.99},
        {"Book2", 19.95},
        {"Book3", 34.50},
        {"Book4", 27.75},
        {"Book5", 30.00},
        {"Book6", 22.50}
    };

    const char *filename = "books.dat"; // File name to store books

    // Write the array of books to a file
    writeBooksToFile(books, 6, filename);

    // Find and display the most costly book from the file
    findMostCostlyBook(filename);

    return 0;
}

