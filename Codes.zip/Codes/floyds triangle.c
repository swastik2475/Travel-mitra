#include <stdio.h>

int main() {
    int rows, num = 1;

    // Prompt the user to enter the number of rows for Floyd's Triangle
    printf("Enter the number of rows for Floyd's Triangle: ");
    scanf("%d", &rows);

    // Loop to print Floyd's Triangle
    for (int i = 1; i <= rows; i++) {
        // Alternate between '1' and '0' in each row
        for (int j = 1; j <= i; j++) {
            // Determine whether to print '1' or '0' based on row and column index
            if ((i + j) % 2 == 0) {
                printf("1");
            } else {
                printf("0");
            }
        }
        printf("\n"); // Move to the next line after each row
    }

    return 0;
}
