//Write a program in C to Find the Number of Lines in a Text File.

#include <stdio.h>

int main() {
    FILE *file;
    char ch;
    int lines = 0;

    // Open the file in read mode
    file = fopen("Sample.txt", "r");

    if (file == NULL) {
        printf("Error opening the file.\n");
        return 1;
    }

    // Count the number of lines
    while ((ch = fgetc(file)) != EOF) {
        if (ch == '\n') {
            lines++;
        }
    }

    // Close the file
    fclose(file);

    printf("Number of lines in the file: %d\n", lines);

    return 0;
}
