#include <stdio.h>

// Function to calculate the series sum
unsigned long long calculateSeriesSum(int terms) {
    unsigned long long sum = 0;
    unsigned long long currentTerm = 0;

    for (int i = 0; i < terms; i++) {
        // Generate the next term in the series (e.g., 1, 11, 111, 1111, ...)
        currentTerm = currentTerm * 10 + 1;
        sum += currentTerm;
    }

    return sum;
}

int main() {
    int terms;

    // Prompt the user to enter the number of terms in the series
    printf("Enter the number of terms in the series: ");
    scanf("%d", &terms);

    // Calculate the sum of the series
    unsigned long long seriesSum = calculateSeriesSum(terms);

    // Display the sum of the series
    printf("Sum of the series for %d terms: %llu\n", terms, seriesSum);

    return 0;
}
