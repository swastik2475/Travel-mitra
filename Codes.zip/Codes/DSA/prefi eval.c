#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

// Stack structure
#define MAX 100
int stack[MAX];
int top = -1;

// Function to push an element to the stack
void push(int x) {
    if (top == MAX - 1) {
        printf("Stack overflow\n");
        return;
    }
    stack[++top] = x;
}

// Function to pop an element from the stack
int pop() {
    if (top == -1) {
        printf("Stack underflow\n");
        exit(1);
    }
    return stack[top--];
}

// Function to check if the character is an operator
int isOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

// Function to evaluate a prefix expression
int evaluatePrefix(char* exp) {
    int i;

    // Traverse the expression from right to left
    for (i = strlen(exp) - 1; i >= 0; i--) {
        // If the character is an operand (number), push it to the stack
        if (isdigit(exp[i])) {
            push(exp[i] - '0');
        }
        // If the character is an operator, pop two elements, apply the operator, and push the result
        else if (isOperator(exp[i])) {
            int op1 = pop();
            int op2 = pop();
            switch (exp[i]) {
                case '+':
                    push(op1 + op2);
                    break;
                case '-':
                    push(op1 - op2);
                    break;
                case '*':
                    push(op1 * op2);
                    break;
                case '/':
                    push(op1 / op2);
                    break;
            }
        }
    }

    // The final result will be at the top of the stack
    return pop();
}

int main() {
    char exp[MAX];

    // Input the prefix expression
    printf("Enter a prefix expression: ");
    scanf("%s", exp);

    // Evaluate the prefix expression
    int result = evaluatePrefix(exp);

    // Output the result
    printf("The result is: %d\n", result);

    return 0;
}
