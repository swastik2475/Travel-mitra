#include <stdio.h>

int bitwiseAddition(int a, int b) {
    while (b != 0) {
        int carry = a & b;
        a ^= b;
        b = carry << 1;
    }
    return a;
}

int main() {
    int num1, num2, result;

    printf("Enter the first integer: ");
    scanf("%d", &num1);
    printf("Enter the second integer: ");
    scanf("%d", &num2);

    result = bitwiseAddition(num1, num2);

    printf("Addition using bitwise operators: %d\n", result);

    return 0;
}
