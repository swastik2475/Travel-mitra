//Write a program in C to find the content of the file and number of lines in a Text File.


#include <stdio.h>

int main() {
    FILE *file;
    char ch;
    int lines = 0;

    // Open the file in read mode
    file = fopen("Sample.txt", "r");

    if (file == NULL) {
        printf("Error opening the file.\n");
        return 1;
    }

    printf("Contents of the file:\n");

    // Read and display the file character by character
    while ((ch = fgetc(file)) != EOF) {
        putchar(ch);  // Display the character on the screen

        // Count the number of lines
        if (ch == '\n') {
            lines++;
        }
    }

    // Close the file
    fclose(file);

    printf("\nNumber of lines in the file: %d\n", lines);

    return 0;
}
