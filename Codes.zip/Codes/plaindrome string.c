//Write a program in C to Check whether a given String is Palindrome or not.

#include <stdio.h>
#include <string.h>

int isPalindrome(char *str);

int main() {
    char str[100];

    printf("Enter a string: ");
    scanf("%s", str);

    if (isPalindrome(str)) {
        printf("%s is a palindrome.\n", str);
    } else {
        printf("%s is not a palindrome.\n", str);
    }

    return 0;
}

int isPalindrome(char *str) {
    int low = 0;
    int high = strlen(str) - 1;

    // Keep comparing characters while they are the same
    while (low < high) {
        if (str[low] != str[high]) {
            return 0;  // Not a palindrome
        }
        low++;  // Move the low index forward
        high--;  // Move the high index backwards
    }

    return 1;  // Is a palindrome
}
