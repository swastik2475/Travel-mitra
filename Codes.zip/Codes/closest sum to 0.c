#include <stdio.h>
#include <stdlib.h>
#include <limits.h> // For INT_MAX and INT_MIN

// Function to compare two integers (used for sorting)
int compare(const void *a, const void *b) {
    return (*(int *)a - *(int *)b);
}

// Function to find the pair of elements with sum closest to zero
void findPairWithClosestSumToZero(int arr[], int n) {
    // Sort the array first
    qsort(arr, n, sizeof(int), compare);

    // Initialize variables to track the pair with closest sum to zero
    int minSum = INT_MAX; // Initialize to a large value
    int closestA, closestB;
    int left = 0, right = n - 1;

    // Two-pointer technique to find the pair with closest sum to zero
    while (left < right) {
        int sum = arr[left] + arr[right];

        // Update the closest pair if the current sum is closer to zero
        if (abs(sum) < abs(minSum)) {
            minSum = sum;
            closestA = arr[left];
            closestB = arr[right];
        }

        // Move the pointers based on the sum
        if (sum < 0) {
            left++; // Increase the left pointer to increase the sum
        } else {
            right--; // Decrease the right pointer to decrease the sum
        }
    }

    // Print the pair of elements with closest sum to zero
    printf("The pair of elements whose sum is closest to zero: [%d, %d]\n", closestA, closestB);
}

int main() {
    int arr[] = {38, 44, 63, -51, -35, 19, 84, -69, 4, -46};
    int n = sizeof(arr) / sizeof(arr[0]);

    // Call the function to find the pair with closest sum to zero
    findPairWithClosestSumToZero(arr, n);

    return 0;
}
