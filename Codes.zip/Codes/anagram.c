#include <stdio.h>
#include <string.h>

// Function to check if two strings are anagrams
int areAnagrams(const char *str1, const char *str2) {
    int freq[256] = {0}; // Frequency array for ASCII characters

    // Calculate frequency of characters in str1
    for (int i = 0; str1[i] != '\0'; i++) {
        freq[(int)str1[i]]++;
    }

    // Decrease frequency of characters in str2
    for (int i = 0; str2[i] != '\0'; i++) {
        freq[(int)str2[i]]--;
    }

    // Check if all elements in frequency array are zero
    for (int i = 0; i < 256; i++) {
        if (freq[i] != 0) {
            return 0; // Not anagrams
        }
    }

    return 1; // Strings are anagrams
}

int main() {
    const char *str1 = "spare";
    const char *str2 = "pears";

    // Check if str1 and str2 are anagrams
    if (areAnagrams(str1, str2)) {
        printf("%s and %s are anagrams.\n", str1, str2);
    } else {
        printf("%s and %s are not anagrams.\n", str1, str2);
    }

    return 0;
}
