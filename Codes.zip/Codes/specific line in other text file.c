#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 1000

int main() {
    FILE *originalFile, *tempFile;
    char originalFileName[] = "original.txt";
    char tempFileName[] = "temp.txt";
    char line[MAX_LINE_LENGTH];
    int lineToReplace = 3; // Specify the line number to replace
    char replacementText[] = "This is the new line."; // Specify the replacement text

    // Open the original file for reading
    originalFile = fopen(originalFileName, "r");
    if (originalFile == NULL) {
        printf("Error: Unable to open the original file '%s' for reading.\n", originalFileName);
        return 1;
    }

    // Open a temporary file for writing
    tempFile = fopen(tempFileName, "w");
    if (tempFile == NULL) {
        printf("Error: Unable to open the temporary file '%s' for writing.\n", tempFileName);
        fclose(originalFile);
        return 1;
    }

    int currentLine = 1;
    // Read the original file line by line
    while (fgets(line, MAX_LINE_LENGTH, originalFile) != NULL) {
        // Check if this is the line to be replaced
        if (currentLine == lineToReplace) {
            // Write the replacement text to the temporary file
            fprintf(tempFile, "%s\n", replacementText);
        } else {
            // Write the original line to the temporary file
            fputs(line, tempFile);
        }
        currentLine++;
    }

    // Close the files
    fclose(originalFile);
    fclose(tempFile);

    // Rename the temporary file to the original file
    if (rename(tempFileName, originalFileName) != 0) {
        printf("Error: Unable to rename the temporary file to '%s'.\n", originalFileName);
        return 1;
    }

    printf("Replacement completed successfully.\n");

    return 0;
}
