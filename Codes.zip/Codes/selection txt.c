//Define a structure Pension with Sr_Id, Name, Age and Income. Store 10 candidates' detail into a file Selection.txt. Find and display Sr_Id and Name who will be pensioner based on Age>=60 and Income<5000 from the Selection.txt.





#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define the structure Pension
struct Pension {
    int sr_id;
    char name[50];
    int age;
    float income;
};

// Function to find and display pensioners
void find_pensioners(struct Pension candidates[], int n) {
    printf("Pensioners:\n");
    for (int i = 0; i < n; i++) {
        if (candidates[i].age >= 60 && candidates[i].income < 5000) {
            printf("Sr_Id: %d, Name: %s\n", candidates[i].sr_id, candidates[i].name);
        }
    }
}

int main() {
    // Define an array to store candidates' details
    struct Pension candidates[10];

    // Store 10 candidates' details into the array
    FILE *file = fopen("Selection.txt", "w");
    if (file == NULL) {
        printf("Error opening file.\n");
        return 1;
    }
    for (int i = 0; i < 10; i++) {
        candidates[i].sr_id = i + 1;
        sprintf(candidates[i].name, "Candidate%d", i + 1);
        candidates[i].age = 60;
        candidates[i].income = 4000 + (i + 1) * 100;
        fprintf(file, "%d,%s,%d,%.2f\n", candidates[i].sr_id, candidates[i].name, candidates[i].age, candidates[i].income);
    }
    fclose(file);

    // Find and display pensioners
    find_pensioners(candidates, 10);

    return 0;
}
