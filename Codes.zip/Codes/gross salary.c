/*Accept the salary of an employee from the user. Calculate the gross salary on the following basis:

#BASIC
1-4000
4001-8000
8001-12000
12000 and above

#HRA
10%
20%
25%
30%

#DA
50%
60%
70%
80%
.
*/


#include <stdio.h>

int main() {
    float salary, grossSalary, hra, da;

    // Accept the salary from the user
    printf("Enter the salary of the employee: ");
    scanf("%f", &salary);

    // Calculate HRA based on BASIC
    if (salary <= 4000) {
        hra = 0.1 * salary;
    } else if (salary <= 8000) {
        hra = 0.2 * salary;
    } else if (salary <= 12000) {
        hra = 0.25 * salary;
    } else {
        hra = 0.3 * salary;
    }

    // Calculate DA based on BASIC
    if (salary <= 4000) {
        da = 0.5 * salary;
    } else if (salary <= 8000) {
        da = 0.6 * salary;
    } else if (salary <= 12000) {
        da = 0.7 * salary;
    } else {
        da = 0.8 * salary;
    }

    // Calculate gross salary
    grossSalary = salary + hra + da;

    // Display the gross salary
    printf("Gross Salary: %.2f\n", grossSalary);

    return 0;
}
