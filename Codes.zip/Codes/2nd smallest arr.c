#include <stdio.h>
#include <limits.h>

int secondSmallest(int arr[], int n) {
    int smallest = INT_MAX;
    int second_smallest = INT_MAX;

    // Find the smallest element in the array
    for (int i = 0; i < n; i++) {
        if (arr[i] < smallest) {
            smallest = arr[i];
        }
    }

    // Find the second smallest element in the array
    for (int i = 0; i < n; i++) {
        if (arr[i] < second_smallest && arr[i] != smallest) {
            second_smallest = arr[i];
        }
    }

    return second_smallest;
}

int main() {
    int arr[] = {12, 4, 8, 7, 2, 15};
    int n = sizeof(arr) / sizeof(arr[0]);

    // Find the second smallest element in the array
    int second_smallest = secondSmallest(arr, n);

    // Print the second smallest element
    printf("The second smallest element in the array is: %d\n", second_smallest);

    return 0;
}
