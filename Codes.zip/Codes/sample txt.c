//Write a program in C to read an existing file Sample.txt and display on the screen.


#include <stdio.h>

int main() {
    FILE *file;
    char ch;

    // Open the file in read mode
    file = fopen("Sample.txt", "r");

    if (file == NULL) {
        printf("Error opening the file.\n");
        return 1;
    }

    // Read and display the file character by character
    while ((ch = fgetc(file)) != EOF) {
        putchar(ch);  // Display the character on the screen
    }

    // Close the file
    fclose(file);

    return 0;
}
