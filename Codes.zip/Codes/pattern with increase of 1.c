#include <stdio.h>

int main() {
    int rows, number = 1;

    // Prompt the user to enter the number of rows for the pyramid
    printf("Enter the number of rows for the pyramid: ");
    scanf("%d", &rows);

    // Outer loop for rows
    for (int i = 1; i <= rows; i++) {
        // Inner loop for printing numbers in each row
        for (int j = 1; j <= i; j++) {
            printf("%d", number);
            number++; // Increment the number for the next position
        }
        printf("\n"); // Move to the next line after each row
    }

    return 0;
}
