#include <stdio.h>

// Function to calculate factorial using pointers
void calculate_factorial(int num, unsigned long long *result) {
    *result = 1;
    for (int i = 2; i <= num; i++) {
        *result *= i;
    }
}

int main() {
    int number;
    unsigned long long factorial = 1;

    printf("Enter a number to find its factorial: ");
    scanf("%d", &number);

    calculate_factorial(number, &factorial);

    printf("Factorial of %d = %llu\n", number, factorial);

    return 0;
}
