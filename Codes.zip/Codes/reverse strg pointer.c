#include <stdio.h>

// Function to print string in reverse using pointer
void print_reverse(const char *str) {
    // Pointer to the end of the string
    const char *end = str;

    // Move pointer to the end of the string
    while (*end != '\0') {
        end++;
    }
    end--; // Move back one position to point to the last character before the null terminator

    // Print characters in reverse order
    while (end >= str) {
        printf("%c", *end);
        end--;
    }
    printf("\n");
}

int main() {
    char str[] = "Hello, World!";
    printf("Original string: %s\n", str);
    printf("Reversed string: ");
    print_reverse(str);
    return 0;
}
