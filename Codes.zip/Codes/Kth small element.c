#include <stdio.h>

// Function to partition the array and return the index of the pivot element
int partition(int arr[], int low, int high) {
    int pivot = arr[high]; // Choose the last element as pivot
    int i = low - 1; // Index of smaller element

    for (int j = low; j <= high - 1; j++) {
        // If current element is smaller than or equal to pivot
        if (arr[j] <= pivot) {
            i++; // Increment index of smaller element
            // Swap arr[i] and arr[j]
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }
    // Swap arr[i + 1] and arr[high] (or pivot)
    int temp = arr[i + 1];
    arr[i + 1] = arr[high];
    arr[high] = temp;
    return i + 1;
}

// Function to find the kth smallest element in the array
int kthSmallest(int arr[], int low, int high, int k) {
    // If k is smaller than number of elements in array
    if (k > 0 && k <= high - low + 1) {
        // Partition the array around last element and get position of pivot element in sorted array
        int index = partition(arr, low, high);

        // If index is same as k
        if (index - low == k - 1) {
            return arr[index];
        }
        // If position is more, recur for left subarray
        if (index - low > k - 1) {
            return kthSmallest(arr, low, index - 1, k);
        }
        // Else recur for right subarray
        return kthSmallest(arr, index + 1, high, k - index + low - 1);
    }
    // If k is more than number of elements in array
    return -1;
}

int main() {
    int arr[] = {12, 4, 8, 7, 2, 15};
    int n = sizeof(arr) / sizeof(arr[0]);
    int k = 3; // Desired kth smallest element
    int kth = kthSmallest(arr, 0, n - 1, k);

    if (kth != -1) {
        printf("The %dth smallest element in the array is: %d\n", k, kth);
    } else {
        printf("Invalid value of k\n");
    }

    return 0;
}
