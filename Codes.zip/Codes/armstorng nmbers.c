//Write a program in C to print Armstrong numbers using the function between range 1 to 400. [Number: 371=33+73+13 so is Armstrong number]


#include <stdio.h>
#include <math.h>

int isArmstrong(int num);

int main() {
    int start = 1, end = 400;

    printf("Armstrong numbers between %d and %d are:\n", start, end);
    for (int i = start; i <= end; i++) {
        if (isArmstrong(i)) {
            printf("%d\n", i);
        }
    }

    return 0;
}

int isArmstrong(int num) {
    int originalNum, remainder, n = 0, result = 0;

    originalNum = num;

    // store the number of digits of num in n
    while (originalNum != 0) {
        originalNum /= 10;
        ++n;
    }

    originalNum = num;

    // calculate the sum of nth power of individual digits
    while (originalNum != 0) {
        remainder = originalNum % 10;
        result += pow(remainder, n);
        originalNum /= 10;
    }

    // check if num is equal to the result
    if (result == num) {
        return 1; // it's an Armstrong number
    } else {
        return 0; // it's not an Armstrong number
    }
}
