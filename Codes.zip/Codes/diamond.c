#include <stdio.h>

int main() {
    int n, i, j, space;

    // Prompt the user to enter the number of rows (n) for the diamond
    printf("Enter the number of rows for the diamond pattern: ");
    scanf("%d", &n);

    // Upper half of the diamond (including the middle row)
    for (i = 1; i <= n; i++) {
        // Print leading spaces
        for (space = 1; space <= n - i; space++) {
            printf(" ");
        }
        // Print asterisks
        for (j = 1; j <= 2 * i - 1; j++) {
            printf("*");
        }
        printf("\n");
    }

    // Lower half of the diamond (excluding the middle row)
    for (i = n - 1; i >= 1; i--) {
        // Print leading spaces
        for (space = 1; space <= n - i; space++) {
            printf(" ");
        }
        // Print asterisks
        for (j = 1; j <= 2 * i - 1; j++) {
            printf("*");
        }
        printf("\n");
    }

    return 0;
}
