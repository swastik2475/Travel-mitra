#include <stdio.h>

// Function to calculate factorial of a number
double factorial(int n) {
    if (n == 0 || n == 1) {
        return 1.0;
    } else {
        double fact = 1.0;
        for (int i = 2; i <= n; i++) {
            fact *= i;
        }
        return fact;
    }
}

// Function to calculate the series sum for a given number of terms and value of x
double calculateSeriesSum(int terms, double x) {
    double sum = 0.0;

    for (int n = 0; n < terms; n++) {
        double term = (double)(pow(x, n) / factorial(n));
        sum += term;
    }

    return sum;
}

int main() {
    double x = 3.0;
    int numTerms[] = {5, 6, 7};

    // Calculate and display the series sum for each number of terms
    for (int i = 0; i < sizeof(numTerms) / sizeof(numTerms[0]); i++) {
        int terms = numTerms[i];
        double sum = calculateSeriesSum(terms, x);
        printf("Sum of %d terms for x = %.1f: %.6f\n", terms, x, sum);
    }

    return 0;
}
