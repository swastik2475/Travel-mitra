#include <stdio.h>
#include <ctype.h>

char find_capital(char *str) {
    if (*str == '\0') {
        return '\0';
    } else if (isupper(*str)) {
        return *str;
    } else {
        return find_capital(str + 1);
    }
}

int main() {
    char str[100];
    printf("Enter a string: ");
    scanf("%s", str);
    char cap = find_capital(str);
    if (cap == '\0') {
        printf("No capital letter found in the string.\n");
    } else {
        printf("The first capital letter in the string is: %c\n", cap);
    }
    return 0;
}