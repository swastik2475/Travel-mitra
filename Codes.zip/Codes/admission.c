#include <stdio.h>

int main() {
    int maths, phy, chem;
    float total;

    // Prompt the user to enter marks in Maths, Physics, and Chemistry
    printf("Enter marks obtained in Mathematics: ");
    scanf("%d", &maths);

    printf("Enter marks obtained in Physics: ");
    scanf("%d", &phy);

    printf("Enter marks obtained in Chemistry: ");
    scanf("%d", &chem);

    // Check eligibility based on the criteria
    if (maths >= 65 && phy >= 55 && chem >= 50) {
        total = maths + phy + chem;
        if (total >= 180 || (maths + phy >= 140)) {
            printf("Congratulations! You are eligible for admission.\n");
        } else {
            printf("Sorry, you are not eligible for admission.\n");
        }
    } else {
        printf("Sorry, you are not eligible for admission.\n");
    }

    return 0;
}
