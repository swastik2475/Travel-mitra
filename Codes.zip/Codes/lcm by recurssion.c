//Write a program in C to find the LCM of two numbers using recursion.


#include <stdio.h>

int findLCM(int a, int b, int step, int lcm);

int main() {
    int num1, num2, lcm;

    printf("Enter first number: ");
    scanf("%d", &num1);

    printf("Enter second number: ");
    scanf("%d", &num2);

    // Find the LCM
    lcm = findLCM(num1, num2, (num1 > num2) ? num1 : num2, num1 * num2);

    printf("LCM of %d and %d is %d\n", num1, num2, lcm);

    return 0;
}

int findLCM(int a, int b, int step, int lcm) {
    if (step % a == 0 && step % b == 0) {
        return step;
    } else {
        return findLCM(a, b, step + lcm, lcm);
    }
}
