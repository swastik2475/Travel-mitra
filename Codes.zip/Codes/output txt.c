#include <stdio.h>

int main() {
    FILE *fp;
    char lines[5][100];  // Array to store 5 lines of maximum 100 characters each
    int i;

    // Open file in write mode
    fp = fopen("output.txt", "w");

    if (fp == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    // Prompt user to enter 5 lines of text
    printf("Enter 5 lines of text:\n");

    for (i = 0; i < 5; i++) {
        fgets(lines[i], sizeof(lines[i]), stdin);  // Read a line from user input
    }

    // Write lines to file
    for (i = 0; i < 5; i++) {
        fprintf(fp, "%s", lines[i]);  // Write each line to the file
    }

    printf("Lines written to output.txt successfully.\n");

    // Close the file
    fclose(fp);

    return 0;
}
