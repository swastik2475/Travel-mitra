#include <stdio.h>

// Function to determine weather condition based on temperature
void determineWeather(float temperature) {
    if (temperature < 0) {
        printf("Freezing weather\n");
    } else if (temperature >= 0 && temperature <= 10) {
        printf("Very Cold weather\n");
    } else if (temperature > 10 && temperature <= 20) {
        printf("Cold weather\n");
    } else if (temperature > 20 && temperature <= 30) {
        printf("Normal in Temp\n");
    } else if (temperature > 30 && temperature <= 40) {
        printf("Its Hot\n");
    } else if (temperature > 40) {
        printf("Its Very Hot\n");
    } else {
        printf("Invalid temperature input\n");
    }
}

int main() {
    float temperature;

    // Prompt the user to enter the temperature in centigrade
    printf("Enter the temperature in centigrade: ");
    scanf("%f", &temperature);

    // Determine the weather condition based on the temperature
    determineWeather(temperature);

    return 0;
}
