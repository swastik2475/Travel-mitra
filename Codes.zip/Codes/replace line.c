#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    FILE *file = fopen("example.txt", "r+");
    if (file == NULL) {
        perror("Error opening file");
        return 1;
    }
    
    int lineNumber;
    printf("Enter line number to replace: ");
    scanf("%d", &lineNumber);
    
    char buffer[1000];
    for (int i = 1; i < lineNumber; ++i)
        if (fgets(buffer, sizeof(buffer), file) == NULL) {
            perror("Line number out of range");
            fclose(file);
            return 1;
        }

    char newText[1000];
    printf("Enter new text: ");
    scanf("%s", newText);
    
    fseek(file, -strlen(buffer), SEEK_CUR);
    fprintf(file, "%s", newText);
    
    fclose(file);
    return 0;
}
