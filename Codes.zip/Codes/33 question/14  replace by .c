#include <stdio.h>

int main() {
    char line[1000];

    printf("Enter a line of mixed text: ");
    fgets(line, sizeof(line), stdin);

    printf("Transformed text:\n");

    for (int i = 0; line[i] != '\0'; i++) {
        if (line[i] >= 'a' && line[i] <= 'z')
            printf("%c", line[i] - 32); // Convert to uppercase
        else if (line[i] >= 'A' && line[i] <= 'Z')
            printf("%c", line[i] + 32); // Convert to lowercase
        else if (line[i] >= '0' && line[i] <= '9')
            printf("O");
        else
            printf("**");
    }

    return 0;
}
