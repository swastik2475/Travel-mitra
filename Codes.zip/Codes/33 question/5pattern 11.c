#include <stdio.h>

int main() {
    int rows;

    printf("Enter the number of rows in the pyramid: ");
    scanf("%d", &rows);

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < rows - i - 1; j++) {
            printf("   ");
        }

        for (int j = i; j >= 0; j--) {
            printf("%2d ", 11 - j);
        }

        for (int j = 1; j <= i; j++) {
            printf("%2d ", 11 - j);
        }

        printf("\n");
    }

    return 0;
}
