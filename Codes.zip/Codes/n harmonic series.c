#include <stdio.h>

int main() {
    int n;
    double sum = 0.0;

    // Prompt the user to enter the number of terms (n) for the harmonic series
    printf("Enter the number of terms (n) for the harmonic series: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Invalid input. Please enter a positive integer for the number of terms.\n");
        return 1;
    }

    // Display the harmonic series terms and calculate their sum
    printf("Harmonic series terms: ");
    for (int i = 1; i <= n; i++) {
        printf("1/%d", i);
        if (i < n) {
            printf(" + ");
        }
        sum += 1.0 / i; // Calculate the sum of harmonic series terms
    }

    // Display the calculated sum of harmonic series terms
    printf("\nSum of %d terms of the harmonic series = %f\n", n, sum);

    return 0;
}
