#include <stdio.h>

int main() {
    char filename[100];

    // Prompt the user to enter the filename to be removed
    printf("Enter the filename to remove: ");
    scanf("%s", filename);

    // Attempt to remove the file
    if (remove(filename) == 0) {
        printf("File '%s' removed successfully.\n", filename);
    } else {
        printf("Error: Unable to remove file '%s'.\n", filename);
    }

    return 0;
}
