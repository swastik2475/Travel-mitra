#include <stdio.h>

int main() {
    int customer_id, units;
    char name[50];
    float charge_per_unit, total_amount, surcharge = 0;

    // Input
    printf("Enter customer ID: ");
    scanf("%d", &customer_id);

    printf("Enter customer name: ");
    scanf("%s", name);

    printf("Enter units consumed: ");
    scanf("%d", &units);

    // Calculate charge per unit based on units consumed
    if (units <= 199) {
        charge_per_unit = 1.20;
    } else if (units >= 200 && units < 400) {
        charge_per_unit = 1.50;
    } else if (units >= 400 && units < 600) {
        charge_per_unit = 1.80;
        // Check if total amount before surcharge is less than Rs. 400
        if ((total_amount = units * charge_per_unit) < 400) {
            surcharge = total_amount * 0.15; // Calculate surcharge
            total_amount += surcharge; // Add surcharge to total amount
        }
    } else {
        charge_per_unit = 2.00;
        // Check if total amount before surcharge is less than Rs. 400
        if ((total_amount = units * charge_per_unit) < 400) {
            surcharge = total_amount * 0.15; // Calculate surcharge
            total_amount += surcharge; // Add surcharge to total amount
        }
    }

    // If the total amount after surcharge is less than Rs. 100, set it to Rs. 100
    if (total_amount < 100) {
        total_amount = 100;
    }

    // Output
    printf("\nElectricity Bill\n");
    printf("Customer ID: %d\n", customer_id);
    printf("Customer Name: %s\n", name);
    printf("Units Consumed: %d\n", units);
    printf("Charge per Unit: %.2f\n", charge_per_unit);
    printf("Surcharge: %.2f\n", surcharge);
    printf("Total Amount to Pay: %.2f\n", total_amount);

    return 0;
}
