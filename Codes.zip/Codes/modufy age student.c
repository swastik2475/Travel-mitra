#include <stdio.h>
#include <stdlib.h>

// Define structure for student
struct student {
    char firstname[50];
    char lastname[50];
    int age;
};

// Function to write student records to file
void write_records() {
    FILE *file = fopen("Record.txt", "w");
    if (file == NULL) {
        printf("Error opening file!\n");
        exit(1);
    }

    struct student students[5] = {
        {"John", "Doe", 20},
        {"Jane", "Smith", 21},
        {"Alice", "Johnson", 22},
        {"Bob", "Williams", 23},
        {"Emily", "Brown", 24}
    };

    for (int i = 0; i < 5; i++) {
        fprintf(file, "%s %s %d\n", students[i].firstname, students[i].lastname, students[i].age);
    }

    fclose(file);
}

// Function to modify age of each student by one year and print records
void modify_and_print_records() {
    FILE *file = fopen("Record.txt", "r");
    if (file == NULL) {
        printf("Error opening file!\n");
        exit(1);
    }

    struct student students[5];

    printf("Modified Student Records:\n");
    for (int i = 0; i < 5; i++) {
        fscanf(file, "%s %s %d", students[i].firstname, students[i].lastname, &students[i].age);
        students[i].age++; // Increment age by one year
        printf("First Name: %s, Last Name: %s, Age: %d\n", students[i].firstname, students[i].lastname, students[i].age);
    }

    fclose(file);
}

int main() {
    write_records();
    modify_and_print_records();
    return 0;
}
