#include <stdio.h>
#include <stdlib.h>

// Define the Merit structure
struct Merit {
    char Applicant_Name[50];
    int Number;
    int Rank;
};

int main() {
    // Create an array of five Merit structures
    struct Merit applicants[5];

    // Open the Application.txt file for writing
    FILE *file = fopen("Application.txt", "w");
    if (file == NULL) {
        printf("Error opening file\n");
        return 1;
    }

    // Store five applicants' details into the file
    for (int i = 0; i < 5; i++) {
        printf("Enter applicant %d's name: ", i + 1);
        scanf("%s", applicants[i].Applicant_Name);

        printf("Enter applicant %d's number: ", i + 1);
        scanf("%d", &applicants[i].Number);

        printf("Enter applicant %d's rank: ", i + 1);
        scanf("%d", &applicants[i].Rank);

        // Write the applicant's details to the file
        fprintf(file, "%s %d %d\n", applicants[i].Applicant_Name, applicants[i].Number, applicants[i].Rank);
    }

    // Close the file
    fclose(file);

    // Open the Application.txt file for reading
    file = fopen("Application.txt", "r");
    if (file == NULL) {
        printf("Error opening file\n");
        return 1;
    }

    // Read and display the name and rank of each applicant
    printf("\nApplicants' details:\n");
    for (int i = 0; i < 5; i++) {
        fscanf(file, "%s %d %d", applicants[i].Applicant_Name, &applicants[i].Number, &applicants[i].Rank);
        printf("Applicant %d's name: %s\n", i + 1, applicants[i].Applicant_Name);
        printf("Applicant %d's rank: %d\n", i + 1, applicants[i].Rank);
    }

    // Close the file
    fclose(file);

    return 0;
}