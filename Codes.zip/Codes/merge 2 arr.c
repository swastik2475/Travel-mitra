#include <stdio.h>

void mergeArrays(int arr1[], int arr2[], int n, int arr3[]) {
    int i = 0, j = 0, k = 0;

    // Merge arrays in descending order
    while (i < n && j < n) {
        if (arr1[i] >= arr2[j]) {
            arr3[k++] = arr1[i++];
        } else {
            arr3[k++] = arr2[j++];
        }
    }

    // Copy remaining elements of arr1, if any
    while (i < n) {
        arr3[k++] = arr1[i++];
    }

    // Copy remaining elements of arr2, if any
    while (j < n) {
        arr3[k++] = arr2[j++];
    }
}

int main() {
    int arr1[] = {23, 19, 13, 3};
    int arr2[] = {20, 16, 10, 7};
    int n = sizeof(arr1) / sizeof(arr1[0]);

    // Array to store merged elements
    int arr3[2 * n];

    // Merge arrays
    mergeArrays(arr1, arr2, n, arr3);

    // Print the merged array
    printf("Merged array: ");
    for (int i = 0; i < 2 * n; i++) {
        printf("%d ", arr3[i]);
    }
    printf("\n");

    return 0;
}
