#include <stdio.h>

void findOddOccurrences(int arr[], int n) {
    int xor_result = 0;
    for (int i = 0; i < n; i++) {
        xor_result ^= arr[i];
    }
    printf("Numbers occurring odd number of times in the array: ");
    for (int i = 0; i < n; i++) {
        if (arr[i] & xor_result) {
            printf("%d ", arr[i]);
        }
    }
    printf("\n");
}

int main() {
    int arr[] = {5, 3, 8, 5, 4, 3, 4, 3, 5};
    int n = sizeof(arr) / sizeof(arr[0]);
    findOddOccurrences(arr, n);
    return 0;
}
