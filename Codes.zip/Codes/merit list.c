//Define a structure Candidate with Roll_No, Name, and Marks. Store 10 candidates detail into a file MeritList.txt. Find and display Roll No and Name of top two candidates from the merit list.




#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Define the Candidate structure
typedef struct {
    int roll_no;
    char name[50];
    float marks;
} Candidate;

int main() {
    FILE *file;
    Candidate candidates[10];
    int i, top1_index = 0, top2_index = 0;

    // Input candidate details
    printf("Enter details of 10 candidates:\n");
    for (i = 0; i < 10; i++) {
        printf("Candidate %d:\n", i + 1);
        printf("Roll No: ");
        scanf("%d", &candidates[i].roll_no);
        printf("Name: ");
        scanf("%s", candidates[i].name);
        printf("Marks: ");
        scanf("%f", &candidates[i].marks);
    }

    // Store details in the file
    file = fopen("MeritList.txt", "w");
    if (file == NULL) {
        printf("Error opening the file.\n");
        return 1;
    }

    for (i = 0; i < 10; i++) {
        fprintf(file, "%d %s %.2f\n", candidates[i].roll_no, candidates[i].name, candidates[i].marks);
    }

    fclose(file);

    // Find top two candidates
    for (i = 1; i < 10; i++) {
        if (candidates[i].marks > candidates[top1_index].marks) {
            top2_index = top1_index;
            top1_index = i;
        } else if (candidates[i].marks > candidates[top2_index].marks && i != top1_index) {
            top2_index = i;
        }
    }

    // Display top two candidates
    printf("\nTop two candidates:\n");
    printf("Roll No: %d, Name: %s\n", candidates[top1_index].roll_no, candidates[top1_index].name);
    printf("Roll No: %d, Name: %s\n", candidates[top2_index].roll_no, candidates[top2_index].name);

    return 0;
}
