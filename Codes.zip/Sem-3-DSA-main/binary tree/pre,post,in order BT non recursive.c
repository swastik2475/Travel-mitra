#include <stdio.h>
#include <stdlib.h>

#define MAX 100

// Define a node for the binary tree
struct Node {
    int data;
    struct Node* left;
    struct Node* right;
};

// Stack structure
struct Stack {
    int top;
    struct Node* items[MAX];
};

// Function to create a new node
struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Function to create a stack
struct Stack* createStack() {
    struct Stack* stack = (struct Stack*)malloc(sizeof(struct Stack));
    stack->top = -1;
    return stack;
}

// Stack operations
int isStackEmpty(struct Stack* stack) {
    return stack->top == -1;
}

void push(struct Stack* stack, struct Node* node) {
    stack->items[++stack->top] = node;
}

struct Node* pop(struct Stack* stack) {
    return stack->items[stack->top--];
}

// Iterative Pre-order traversal
void preOrder(struct Node* root) {
    struct Stack* stack = createStack();
    if (root == NULL) return;

    push(stack, root);
    while (!isStackEmpty(stack)) {
        struct Node* node = pop(stack);
        printf("%d ", node->data);

        if (node->right) push(stack, node->right);
        if (node->left) push(stack, node->left);
    }
    printf("\n");
}

// Iterative In-order traversal
void inOrder(struct Node* root) {
    struct Stack* stack = createStack();
    struct Node* current = root;

    while (current != NULL || !isStackEmpty(stack)) {
        while (current != NULL) {
            push(stack, current);
            current = current->left;
        }
        current = pop(stack);
        printf("%d ", current->data);
        current = current->right;
    }
    printf("\n");
}

// Iterative Post-order traversal
void postOrder(struct Node* root) {
    struct Stack* stack1 = createStack();
    struct Stack* stack2 = createStack();
    if (root == NULL) return;

    push(stack1, root);
    while (!isStackEmpty(stack1)) {
        struct Node* node = pop(stack1);
        push(stack2, node);

        if (node->left) push(stack1, node->left);
        if (node->right) push(stack1, node->right);
    }
    while (!isStackEmpty(stack2)) {
        struct Node* node = pop(stack2);
        printf("%d ", node->data);
    }
    printf("\n");
}

// Main function
int main() {
    struct Node* root = createNode(1);
    root->left = createNode(2);
    root->right = createNode(3);
    root->left->left = createNode(4);
    root->left->right = createNode(5);

    printf("Pre-order traversal: ");
    preOrder(root);

    printf("In-order traversal: ");
    inOrder(root);

    printf("Post-order traversal: ");
    postOrder(root);

    return 0;
}
