#include <stdio.h>
#include <stdlib.h>

#define MAX 10

void topologicalSort(int adj[MAX][MAX], int n) {
    int inDegree[MAX] = {0};

    // Calculate in-degrees of all vertices
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (adj[i][j] == 1) {
                inDegree[j]++;
            }
        }
    }

    int queue[MAX], front = -1, rear = -1;

    // Enqueue vertices with in-degree 0
    for (int i = 0; i < n; i++) {
        if (inDegree[i] == 0) {
            queue[++rear] = i;
        }
    }

    int count = 0;
    while (front != rear) {
        int v = queue[++front];
        printf("%d ", v);
        count++;

        for (int i = 0; i < n; i++) {
            if (adj[v][i] == 1) {
                if (--inDegree[i] == 0) {
                    queue[++rear] = i;
                }
            }
        }
    }

    if (count != n) {
        printf("\nGraph has a cycle, topological sort not possible.\n");
    } else {
        printf("\nTopological sort completed.\n");
    }
}

int main() {
    int n;
    int adj[MAX][MAX];

    printf("Enter the number of vertices: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix (0 or 1 for edges):\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &adj[i][j]);
        }
    }

    printf("Topological Sort: ");
    topologicalSort(adj, n);

    return 0;
}
