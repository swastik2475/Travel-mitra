#include <stdio.h>
#include <stdlib.h>

// Define a node for singly linked list
struct Node {
    int data;
    struct Node* next;
};

// Function to add a node at the end of the list
void addNode(struct Node** head, int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    struct Node* temp = *head;
    newNode->data = data;
    newNode->next = NULL;

    if (*head == NULL) {
        *head = newNode;
        return;
    }
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = newNode;
}

// Function to concatenate two lists
void concatenate(struct Node** head1, struct Node** head2) {
    struct Node* temp = *head1;
    if (temp == NULL) {
        *head1 = *head2;
        return;
    }
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = *head2;
}

// Function to display the list
void displayList(struct Node* head) {
    while (head != NULL) {
        printf("%d -> ", head->data);
        head = head->next;
    }
    printf("NULL\n");
}

// Main function to test concatenation
int main() {
    struct Node* head1 = NULL;
    struct Node* head2 = NULL;
    int choice, data;

    printf("Enter elements for List 1 (enter -1 to stop): ");
    while (1) {
        scanf("%d", &data);
        if (data == -1) break;
        addNode(&head1, data);
    }

    printf("Enter elements for List 2 (enter -1 to stop): ");
    while (1) {
        scanf("%d", &data);
        if (data == -1) break;
        addNode(&head2, data);
    }

    printf("List 1: ");
    displayList(head1);
    printf("List 2: ");
    displayList(head2);

    concatenate(&head1, &head2);
    printf("Concatenated List: ");
    displayList(head1);

    return 0;
}
