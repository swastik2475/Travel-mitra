#include <stdio.h>
#include <stdlib.h>

// Define a node for circular linked list
struct Node {
    int data;
    struct Node* next;
};

// Function to add a node at the end
void addNode(struct Node** head, int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    struct Node* temp = *head;
    newNode->data = data;
    newNode->next = *head;

    if (*head != NULL) {
        while (temp->next != *head) {
            temp = temp->next;
        }
        temp->next = newNode;
    } else {
        newNode->next = newNode; // For the first node
        *head = newNode;
    }
}

// Function to remove a node with specific data
void removeNode(struct Node** head, int key) {
    if (*head == NULL) return;

    struct Node *temp = *head, *prev;

    if (temp->data == key && temp->next == *head) { // Single node
        *head = NULL;
        free(temp);
        return;
    }

    while (temp->data != key) { // Find the node
        if (temp->next == *head) return;
        prev = temp;
        temp = temp->next;
    }

    if (temp == *head) { // Deleting the head node
        prev = *head;
        while (prev->next != *head) prev = prev->next;
        *head = temp->next;
        prev->next = *head;
        free(temp);
    } else if (temp->next == *head) { // Deleting the last node
        prev->next = *head;
        free(temp);
    } else { // Delete in between
        prev->next = temp->next;
        free(temp);
    }
}

// Function to display all nodes in the list
void displayList(struct Node* head) {
    if (head == NULL) {
        printf("The list is empty.\n");
        return;
    }
    struct Node* temp = head;
    do {
        printf("%d -> ", temp->data);
        temp = temp->next;
    } while (temp != head);
    printf("HEAD\n");
}

// Main function for user interaction
int main() {
    struct Node* head = NULL;
    int choice, data;

    while (1) {
        printf("\n1. Add element\n2. Remove element\n3. Display list\n4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the element to add: ");
                scanf("%d", &data);
                addNode(&head, data);
                break;
            case 2:
                printf("Enter the element to remove: ");
                scanf("%d", &data);
                removeNode(&head, data);
                break;
            case 3:
                printf("The circular linked list is: ");
                displayList(head);
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
    return 0;
}
