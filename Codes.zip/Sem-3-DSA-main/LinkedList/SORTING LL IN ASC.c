#include <stdio.h>
#include <stdlib.h>

// Define a node for singly linked list
struct Node {
    int data;
    struct Node* next;
};

// Function to add a node at the beginning
void addNode(struct Node** head, int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = *head;
    *head = newNode;
}

// Function to sort the linked list
void sortList(struct Node* head) {
    struct Node* i = head;
    struct Node* j = NULL;
    int temp;
    if (head == NULL) return;

    while (i != NULL) {
        j = i->next;
        while (j != NULL) {
            if (i->data > j->data) {
                temp = i->data;
                i->data = j->data;
                j->data = temp;
            }
            j = j->next;
        }
        i = i->next;
    }
}

// Function to display the list
void displayList(struct Node* head) {
    while (head != NULL) {
        printf("%d -> ", head->data);
        head = head->next;
    }
    printf("NULL\n");
}

// Main function
int main() {
    struct Node* head = NULL;
    int choice, data;

    printf("Enter elements to create list (enter -1 to stop): ");
    while (1) {
        scanf("%d", &data);
        if (data == -1) break;
        addNode(&head, data);
    }

    printf("Original List: ");
    displayList(head);

    sortList(head);
    printf("Sorted List: ");
    displayList(head);

    return 0;
}
