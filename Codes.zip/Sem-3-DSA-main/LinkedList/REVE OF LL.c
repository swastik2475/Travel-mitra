#include <stdio.h>
#include <stdlib.h>

// Define a node for singly linked list
struct Node {
    int data;
    struct Node* next;
};

// Function to add a node at the beginning
void addNode(struct Node** head, int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = *head;
    *head = newNode;
}

// Function to reverse the linked list
void reverseList(struct Node** head) {
    struct Node *prev = NULL, *current = *head, *next = NULL;
    while (current != NULL) {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }
    *head = prev;
}

// Function to display the list
void displayList(struct Node* head) {
    while (head != NULL) {
        printf("%d -> ", head->data);
        head = head->next;
    }
    printf("NULL\n");
}

// Main function
int main() {
    struct Node* head = NULL;
    int choice, data;

    printf("Enter elements to create list (enter -1 to stop): ");
    while (1) {
        scanf("%d", &data);
        if (data == -1) break;
        addNode(&head, data);
    }

    printf("Original List: ");
    displayList(head);

    reverseList(&head);
    printf("Reversed List: ");
    displayList(head);

    return 0;
}
