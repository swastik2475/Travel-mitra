#include <stdio.h>
#include <stdlib.h>

// Define a node for doubly linked list
struct Node {
    int data;
    struct Node* prev;
    struct Node* next;
};

// Function to add a node at the beginning
void addNode(struct Node** head, int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = *head;
    newNode->prev = NULL;
    if (*head != NULL)
        (*head)->prev = newNode;
    *head = newNode;
}

// Function to remove a node with specific data
void removeNode(struct Node** head, int key) {
    struct Node* temp = *head;

    // Traverse the list to find the node with key
    while (temp != NULL && temp->data != key) {
        temp = temp->next;
    }

    if (temp == NULL) return;

    // Update pointers and free the node
    if (temp->prev != NULL)
        temp->prev->next = temp->next;
    else
        *head = temp->next;
    if (temp->next != NULL)
        temp->next->prev = temp->prev;

    free(temp);
}

// Function to display all nodes in the list
void displayList(struct Node* node) {
    while (node != NULL) {
        printf("%d <-> ", node->data);
        node = node->next;
    }
    printf("NULL\n");
}

// Main function for user interaction
int main() {
    struct Node* head = NULL;
    int choice, data;

    while (1) {
        printf("\n1. Add element\n2. Remove element\n3. Display list\n4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the element to add: ");
                scanf("%d", &data);
                addNode(&head, data);
                break;
            case 2:
                printf("Enter the element to remove: ");
                scanf("%d", &data);
                removeNode(&head, data);
                break;
            case 3:
                printf("The doubly linked list is: ");
                displayList(head);
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
    return 0;
}
