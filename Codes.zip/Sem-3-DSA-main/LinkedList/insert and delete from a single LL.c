#include <stdio.h>
#include <stdlib.h>

// Define a node for singly linked list
struct Node {
    int data;
    struct Node* next;
};

// Function to add a node at the beginning
void addNode(struct Node** head, int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = *head;
    *head = newNode;
}

// Function to remove a node with specific data
void removeNode(struct Node** head, int key) {
    struct Node* temp = *head, *prev = NULL;

    // Check if head node contains the key
    if (temp != NULL && temp->data == key) {
        *head = temp->next;
        free(temp);
        return;
    }

    // Search for the key to be deleted
    while (temp != NULL && temp->data != key) {
        prev = temp;
        temp = temp->next;
    }

    // If key was not found
    if (temp == NULL) return;

    // Unlink the node and free memory
    prev->next = temp->next;
    free(temp);
}

// Function to display all nodes in the list
void displayList(struct Node* node) {
    while (node != NULL) {
        printf("%d -> ", node->data);
        node = node->next;
    }
    printf("NULL\n");
}

// Main function for user interaction
int main() {
    struct Node* head = NULL;
    int choice, data;

    while (1) {
        printf("\n1. Add element\n2. Remove element\n3. Display list\n4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the element to add: ");
                scanf("%d", &data);
                addNode(&head, data);
                break;
            case 2:
                printf("Enter the element to remove: ");
                scanf("%d", &data);
                removeNode(&head, data);
                break;
            case 3:
                printf("The linked list is: ");
                displayList(head);
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
    return 0;
}
