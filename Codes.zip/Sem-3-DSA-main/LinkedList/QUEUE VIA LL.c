#include <stdio.h>
#include <stdlib.h>

// Define a node for the queue
struct Node {
    int data;
    struct Node* next;
};

// Queue front and rear pointers
struct Node* front = NULL;
struct Node* rear = NULL;

// Function to enqueue an element
void enqueue(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;
    if (rear == NULL) {
        front = rear = newNode;
        return;
    }
    rear->next = newNode;
    rear = newNode;
}

// Function to dequeue an element
int dequeue() {
    if (front == NULL) {
        printf("Queue underflow\n");
        return -1;
    }
    struct Node* temp = front;
    int data = front->data;
    front = front->next;
    if (front == NULL)
        rear = NULL;
    free(temp);
    return data;
}

// Function to display the queue
void displayQueue() {
    struct Node* temp = front;
    while (temp != NULL) {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

// Main function for queue operations
int main() {
    int choice, data;

    while (1) {
        printf("\n1. Enqueue\n2. Dequeue\n3. Display Queue\n4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the element to enqueue: ");
                scanf("%d", &data);
                enqueue(data);
                break;
            case 2:
                printf("Dequeued element: %d\n", dequeue());
                break;
            case 3:
                printf("The queue is: ");
                displayQueue();
                break;
            case 4:
                exit(0);
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
    return 0;
}
