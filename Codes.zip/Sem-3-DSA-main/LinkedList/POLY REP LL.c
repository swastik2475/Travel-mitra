#include <stdio.h>
#include <stdlib.h>

// Define a node for polynomial linked list
struct Node {
    int coefficient;
    int exponent;
    struct Node* next;
};

// Function to add a term to the polynomial
void addTerm(struct Node** head, int coefficient, int exponent) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->coefficient = coefficient;
    newNode->exponent = exponent;
    newNode->next = NULL;

    if (*head == NULL || (*head)->exponent < exponent) {
        newNode->next = *head;
        *head = newNode;
    } else {
        struct Node* temp = *head;
        while (temp->next != NULL && temp->next->exponent >= exponent) {
            temp = temp->next;
        }
        newNode->next = temp->next;
        temp->next = newNode;
    }
}

// Function to display the polynomial
void displayPolynomial(struct Node* head) {
    while (head != NULL) {
        printf("%dx^%d", head->coefficient, head->exponent);
        head = head->next;
        if (head != NULL) {
            printf(" + ");
        }
    }
    printf("\n");
}

// Main function
int main() {
    struct Node* poly = NULL;
    int terms, coeff, exp;

    printf("Enter the number of terms in the polynomial: ");
    scanf("%d", &terms);

    for (int i = 0; i < terms; i++) {
        printf("Enter coefficient and exponent: ");
        scanf("%d %d", &coeff, &exp);
        addTerm(&poly, coeff, exp);
    }

    printf("The polynomial is: ");
    displayPolynomial(poly);

    return 0;
}
